# Türkçe Kelime Veritabanı
